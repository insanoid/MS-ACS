package com.uob.mycal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.uob.mycal.adapters.CalKey;
import com.uob.mycal.adapters.CalKeyboardAdapter;

public class CalculatorActivity extends Activity {

	CalKeyboardAdapter keyboardAdapater;
	GridView keyboardGrid;
	TextView inputTextView, operationStackTextView;
	List<String> operations = new ArrayList<String>();
	Typeface face;
	Boolean executionState = false;


	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);

		getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
		getActionBar().hide();
		setContentView(R.layout.activity_cal);

		keyboardGrid = (GridView) findViewById(R.id.buttonsGridView);
		inputTextView = (TextView) findViewById(R.id.inputCurrent);
		operationStackTextView = (TextView) findViewById(R.id.inputStack);

		keyboardGrid.setNumColumns(4);
		keyboardGrid.setPadding(0, 0, 0, 0);

		face = Typeface.createFromAsset(getAssets(), "digital.ttf");
		inputTextView.setTypeface(face);
		operationStackTextView.setTypeface(face);

		keyboardAdapater = new CalKeyboardAdapter(this, new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				handleInput(v.getTag());
			}
		});
		keyboardGrid.setAdapter(keyboardAdapater);

	}

	void handleInput(Object k) {
		CalKey key = (CalKey) k;

		switch (key.getContentType()) {
		case NUM:
			if (inputTextView.getText().equals(this.getString(R.string.disp)) == false) {
				inputTextView.setText(inputTextView.getText()
						+ this.getString(key.getContentText()));
			} else {
				inputTextView.setText(this.getString(key.getContentText()));
			}
			break;
		case OPT:
			moveOperandToStack(key);

			break;
		case CLR:
			switch (key.getContentText()) {
			case R.string.clear:
				inputTextView.setText(R.string.zero);
				break;
			case R.string.mc:
				reset();
				break;
			case R.string.delete:
				if (inputTextView.getText().equals(this.getString(R.string.disp)) == false) {
					String str = inputTextView.getText().toString();
					if (str.length() > 0 && str.charAt(str.length()-1)=='x') {
					    str = str.substring(0, str.length()-1);
					    inputTextView.setText(str);
					  }
					;
				}
				break;
			default:
				break;
			}
			
		case BRCKT:
			
			break;
		case EXEC:
			execute();
			break;
		case PNT:
			if (inputTextView.getText().equals(this.getString(R.string.disp)) == false) {
				if (!inputTextView.getText().toString()
						.contains(this.getString(key.getContentText()))) {
					inputTextView.setText(inputTextView.getText()
							+ this.getString(key.getContentText()));
				}
			} else {
				inputTextView.setText(this.getString(R.string.zero)
						+ this.getString(key.getContentText()));
			}
			break;
		default:
			break;
		}

	}

	
	void reset() {

		executionState = false;
		inputTextView.setText(R.string.disp);
		operationStackTextView.setText("");
		operations.clear();
	}

	void moveOperandToStack(CalKey key) {
		if(executionState==true){
			if(Double.parseDouble(inputTextView.getText().toString())==0 && isNumeric(operationStackTextView.getText().toString())){
				operations.add(operationStackTextView.getText().toString());
				operations.add(this.getString(key.getContentText()));
				operationStackTextView.append(" "+ this.getString(key.getContentText()));
				inputTextView.setText(R.string.disp);
				executionState = false;
				return;
			}else{
				operationStackTextView.setText("");
			}
		}
		executionState = false;
		if(operationStackTextView.getText().toString().equals(this.getString(R.string.zero))){
			operationStackTextView.setText("");
		}
		operations.add(inputTextView.getText().toString());
		operations.add(this.getString(key.getContentText()));
		if(operationStackTextView.getText().toString().length()>0)
			operationStackTextView.append(" ");
		operationStackTextView.append(inputTextView.getText().toString()
				+" "+ this.getString(key.getContentText()));
		inputTextView.setText(R.string.disp);

	}

	void execute() {

		operations.add(inputTextView.getText().toString());

		Stack<String> postFixNotation = convert(operations);
		Double d = evaluate(postFixNotation);
		operationStackTextView.setText(d.toString());
		inputTextView.setText(this.getString(R.string.disp));

		operations.clear();

		executionState = true;
	}

	public boolean isNumeric(String input) {
		try {
			Double.parseDouble(input);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public Stack<String> convert(List<String> opts) {

		Stack<String> postFix = new Stack<String>();
		Stack<String> op = new Stack<String>();

		for (int i = 0; i < opts.size(); i++) {
			String current = opts.get(i);

			if (isNumeric(current)) {
				postFix.add(current);
			} else if (isOperator(current.toCharArray()[0])) {
				while (!op.isEmpty()
						&& priority(op.peek().charAt(0)) >= priority(current
								.toCharArray()[0])) {
					postFix.add(op.pop());
				}
				op.push(current);
			}
		}

		while (!op.isEmpty()) {
			postFix.add(op.pop());
		}

		Log.d("POST FIX NOTATION", "" + Arrays.deepToString(postFix.toArray()));
		return postFix;
	}

	private boolean isOperator(char ch) {
		Log.d("-- CHAR CHECK", " - " + ch);
		return ch == '^' || ch == 'x' || ch == '/' || ch == '+' || ch == '-';
	}

	private int priority(char operator) {
		switch (operator) {
		case '^':
			return 3;
		case 'x':
		case '/':
			return 2;
		case '+':
		case '-':
			return 1;
		}
		return 0;
	}

	public Double evaluate(Stack<String> postfix) {

		Stack<Double> eval = new Stack<Double>();

		try{
			for (int i = 0; i < postfix.size(); i++) {
				String current = postfix.get(i);

				if (isOperator(current.charAt(0))) {
					switch (current.charAt(0)) {
					case '+':
						eval.push(eval.pop() + eval.pop());
						break;
					case 'x':
						eval.push(eval.pop() * eval.pop());
						break;
					case '-':
						double subop1 = eval.pop();
						double subop2 = eval.pop();
						eval.push(subop2-subop1);
						break;
					case '/':
						double divop1 = eval.pop();
						double divop2 = eval.pop();
						eval.push(divop2/divop1);
						break;
					case '^':
						double sqop1 = eval.pop();
						double sqop2 = eval.pop();
						eval.push(Math.pow(sqop2, sqop1));
						break;
					}
				} else if (isNumeric(current)) {
					eval.push(Double.parseDouble(current));
				}
			}
		}catch(Exception e){

			Toast.makeText(this,
					this.getString(R.string.error_message),
					Toast.LENGTH_SHORT).show();


			reset();
		}
		if (!eval.isEmpty())
			return eval.pop();
		else
			return 0.0;
	}

}