/** Automatically generated file. DO NOT MODIFY */
package com.uob.mycal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}