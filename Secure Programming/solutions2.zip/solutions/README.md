Please note the shell scripts work as follows: ./exploit <ip address>


Challenge 1
-----------
Solution : Standard buffer overflow.
- Printed buffer address and then calculate the difference (280) in the current frame.
- Uses shell binding at port 3568 then creates a second client to access it through another tell net client.


Challenge 2
-----------
Solution : An alternative technique instead of the previous one where port binding was done, the shell-code is to read the file (cat secret.txt) and then pass it on to the to the usesr buffer which then prints it to the connected client.
