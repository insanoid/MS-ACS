var config = {}

config.mongo = {};
config.web = {};
config.push = {};
config.mongo.collection = {};

config.max_trends_result = 15;

config.mongo.host = 'localhost';
config.mongo.port = 27017;
/*
config.mongo.username = 'karthikeyaudupa';
config.mongo.password = '1123581321';
*/

config.mongo.db = 'websensedb';
config.mongo.pool_size = 10;
config.mongo.collection.user = 'users';
config.mongo.collection.app_usage = 'appusage';
config.mongo.collection.app_info = 'appinfo';
config.mongo.collection.web_info = 'webinfo';
config.mongo.collection.geo_tags = 'geotags';
config.mongo.collection.context_info = 'contextinfo';

config.push.radius = 500; //in feet.
config.push.gcmkey = 'AIzaSyBpog7NZc0AjKVLkJ2wMXNmP6Uu2D1x4Jo';

config.ignore_packages = [ "com.android.systemui", "com.google.android.googlequicksearchbox", null, "android", "com.android.settings", "com.sec.android.launcher", "com.sec.android.app.launcher","com.android.launcher" ];

config.weka_ignore_packages = [ "com.android.systemui", "com.google.android.googlequicksearchbox", null, "android", "com.android.settings", "com.sec.android.launcher", "com.sec.android.app.launcher","com.android.launcher","com.uob.websense","com..lauch" ];

config.web.port = process.env.PORT || 3000;
module.exports = config;