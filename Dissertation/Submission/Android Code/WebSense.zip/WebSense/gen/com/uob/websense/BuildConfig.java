/** Automatically generated file. DO NOT MODIFY */
package com.uob.websense;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}